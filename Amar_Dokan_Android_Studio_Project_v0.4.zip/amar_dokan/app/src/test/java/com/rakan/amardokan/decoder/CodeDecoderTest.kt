package com.rakan.amardokan.decoder

import org.junit.Assert.assertEquals
import org.junit.Test

class CodeDecoderTest {
    @Test fun decodesSecondSystemExamples() {
        assertEquals(215, CodeDecoder.decode("10EA").getOrThrow())
        assertEquals(22, CodeDecoder.decode("3A").getOrThrow())
        assertEquals(28, CodeDecoder.decode("A3").getOrThrow())
        assertEquals(420, CodeDecoder.decode("10EEA5").getOrThrow())
    }

    @Test fun decodesFirstSystem() {
        assertEquals(9, CodeDecoder.decode("EFJ").getOrThrow())
    }

    @Test fun rejectsInvalidCode() {
        assertEquals(true, CodeDecoder.decode("XYZ").isFailure)
    }
}
