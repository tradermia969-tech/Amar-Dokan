package com.rakan.amardokan.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "business_files")
data class BusinessFile(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val createdAt: Long = System.currentTimeMillis())

@Entity(tableName = "products", foreignKeys = [ForeignKey(entity = BusinessFile::class, parentColumns = ["id"], childColumns = ["businessId"], onDelete = ForeignKey.CASCADE)], indices = [Index("businessId"), Index(value = ["businessId", "code"], unique = true)])
data class Product(@PrimaryKey(autoGenerate = true) val id: Long = 0, val businessId: Long, val name: String, val code: String, val purchasePrice: Double, val sellingPrice: Double, val stock: Int)

@Entity(tableName = "ledger_entries", foreignKeys = [ForeignKey(entity = BusinessFile::class, parentColumns = ["id"], childColumns = ["businessId"], onDelete = ForeignKey.CASCADE)], indices = [Index("businessId"), Index(value = ["businessId", "createdAt"])])
data class LedgerEntry(@PrimaryKey(autoGenerate = true) val id: Long = 0, val businessId: Long, /** SALE, PURCHASE, INCOME, EXPENSE */ val type: String, /** CASH, BKASH, NAGAD, BANK */ val account: String, val amount: Double, val note: String = "", val createdAt: Long = System.currentTimeMillis())

@Entity(tableName = "stock_transactions", foreignKeys = [ForeignKey(entity = BusinessFile::class, parentColumns = ["id"], childColumns = ["businessId"], onDelete = ForeignKey.CASCADE), ForeignKey(entity = Product::class, parentColumns = ["id"], childColumns = ["productId"], onDelete = ForeignKey.CASCADE)], indices = [Index("businessId"), Index("productId"), Index("createdAt")])
data class StockTransaction(@PrimaryKey(autoGenerate = true) val id: Long = 0, val businessId: Long, val productId: Long, /** PURCHASE or SALE */ val type: String, val quantity: Int, val unitPrice: Double, val total: Double, val account: String, val note: String = "", val createdAt: Long = System.currentTimeMillis())

@Dao
abstract class StoreDao {
    @Query("SELECT * FROM business_files ORDER BY createdAt") abstract fun files(): Flow<List<BusinessFile>>
    @Insert abstract suspend fun addFile(file: BusinessFile): Long
    @Update abstract suspend fun updateFile(file: BusinessFile)
    @Delete abstract suspend fun deleteFile(file: BusinessFile)
    @Query("SELECT * FROM products WHERE businessId=:businessId ORDER BY name") abstract fun products(businessId: Long): Flow<List<Product>>
    @Query("SELECT * FROM products WHERE id=:productId AND businessId=:businessId LIMIT 1") abstract suspend fun findProduct(productId: Long, businessId: Long): Product?
    @Insert abstract suspend fun addProduct(product: Product)
    @Update abstract suspend fun updateProduct(product: Product)
    @Delete abstract suspend fun deleteProduct(product: Product)
    @Query("SELECT * FROM ledger_entries WHERE businessId=:businessId ORDER BY createdAt DESC") abstract fun ledger(businessId: Long): Flow<List<LedgerEntry>>
    @Insert abstract suspend fun addLedger(entry: LedgerEntry)
    @Query("SELECT COALESCE(SUM(amount),0) FROM ledger_entries WHERE businessId=:businessId AND type='SALE'") abstract fun salesTotal(businessId: Long): Flow<Double>
    @Query("SELECT COUNT(*) FROM products WHERE businessId=:businessId") abstract fun productCount(businessId: Long): Flow<Int>
    @Query("SELECT * FROM stock_transactions WHERE businessId=:businessId ORDER BY createdAt DESC") abstract fun stockHistory(businessId: Long): Flow<List<StockTransaction>>
    @Query("SELECT COALESCE(SUM(total),0) FROM stock_transactions WHERE businessId=:businessId AND type='SALE'") abstract fun transactionSalesTotal(businessId: Long): Flow<Double>
    @Query("SELECT COALESCE(SUM(total),0) FROM stock_transactions WHERE businessId=:businessId AND type='PURCHASE'") abstract fun purchaseTotal(businessId: Long): Flow<Double>
    @Query("UPDATE products SET stock = stock + :quantity WHERE id=:productId AND businessId=:businessId") abstract suspend fun increaseStock(productId: Long, businessId: Long, quantity: Int): Int
    @Query("UPDATE products SET stock = stock - :quantity WHERE id=:productId AND businessId=:businessId AND stock >= :quantity") abstract suspend fun decreaseStock(productId: Long, businessId: Long, quantity: Int): Int
    @Insert abstract suspend fun addStockTransaction(transaction: StockTransaction)

    @Transaction
    open suspend fun recordPurchase(businessId: Long, productId: Long, quantity: Int, unitPrice: Double, account: String, note: String = "") {
        require(quantity > 0) { "পরিমাণ শূন্যের বেশি হতে হবে" }; require(unitPrice >= 0.0) { "মূল্য সঠিক নয়" }
        val product = requireNotNull(findProduct(productId, businessId)) { "এই ব্যবসার ফাইলে পণ্যটি পাওয়া যায়নি" }
        check(increaseStock(productId, businessId, quantity) == 1) { "স্টক আপডেট করা যায়নি" }
        val total = quantity * unitPrice
        addStockTransaction(StockTransaction(businessId=businessId, productId=productId, type="PURCHASE", quantity=quantity, unitPrice=unitPrice, total=total, account=account, note=note))
        addLedger(LedgerEntry(businessId=businessId, type="PURCHASE", account=account, amount=total, note=note.ifBlank { "${product.name} ক্রয় × $quantity" }))
    }

    @Transaction
    open suspend fun recordSale(businessId: Long, productId: Long, quantity: Int, unitPrice: Double, account: String, note: String = "") {
        require(quantity > 0) { "পরিমাণ শূন্যের বেশি হতে হবে" }; require(unitPrice >= 0.0) { "মূল্য সঠিক নয়" }
        val product = requireNotNull(findProduct(productId, businessId)) { "এই ব্যবসার ফাইলে পণ্যটি পাওয়া যায়নি" }
        check(decreaseStock(productId, businessId, quantity) == 1) { "পর্যাপ্ত স্টক নেই" }
        val total = quantity * unitPrice
        addStockTransaction(StockTransaction(businessId=businessId, productId=productId, type="SALE", quantity=quantity, unitPrice=unitPrice, total=total, account=account, note=note))
        addLedger(LedgerEntry(businessId=businessId, type="SALE", account=account, amount=total, note=note.ifBlank { "${product.name} বিক্রি × $quantity" }))
    }

    @Transaction open suspend fun recordExpense(businessId: Long, account: String, amount: Double, note: String) {
        require(amount > 0.0) { "খরচের পরিমাণ সঠিক নয়" }; addLedger(LedgerEntry(businessId=businessId, type="EXPENSE", account=account, amount=amount, note=note))
    }
    @Transaction open suspend fun recordIncome(businessId: Long, account: String, amount: Double, note: String) {
        require(amount > 0.0) { "আয়ের পরিমাণ সঠিক নয়" }; addLedger(LedgerEntry(businessId=businessId, type="INCOME", account=account, amount=amount, note=note))
    }
    @Query("SELECT COALESCE(SUM(CASE WHEN type IN ('SALE','INCOME') THEN amount ELSE -amount END),0) FROM ledger_entries WHERE businessId=:businessId AND account=:account") abstract fun accountBalance(businessId: Long, account: String): Flow<Double>
}

@Database(entities = [BusinessFile::class, Product::class, LedgerEntry::class, StockTransaction::class], version = 2, exportSchema = true)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): StoreDao
    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "amar_dokan.db").fallbackToDestructiveMigration().build().also { INSTANCE = it }
        }
    }
}
