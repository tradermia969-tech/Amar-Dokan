package com.rakan.amardokan

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.rakan.amardokan.data.*
import com.rakan.amardokan.decoder.CodeDecoder
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

private val Green = Color(0xFF176B5B)
private val Ink = Color(0xFF172B27)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = AppDatabase.get(this).dao()
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = Color(0xFFE5A94D), background = Color(0xFFF5F7F6))) { AppOpening(dao) } }
    }
}


@Composable
private fun AppOpening(dao: StoreDao) {
    var showOpening by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(2_000)
        showOpening = false
    }
    if (showOpening) OpeningScreen() else AmarDokanApp(dao)
}

@Composable
private fun OpeningScreen() {
    Box(
        modifier = Modifier.fillMaxSize().background(
            brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                colors = listOf(Color(0xFF0D4038), Color(0xFF176B5B), Color(0xFF0B2925))
            )
        ),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Surface(
                modifier = Modifier.size(94.dp),
                shape = RoundedCornerShape(28.dp),
                color = Color.White.copy(alpha = 0.12f),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.28f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Store, contentDescription = "Amar Dokan", tint = Color.White, modifier = Modifier.size(52.dp))
                }
            }
            Text(
                text = "Amar Dokan_ আমার দোকান",
                color = Color.White,
                fontSize = 25.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                textAlign = TextAlign.Center,
                letterSpacing = 0.3.sp
            )
            Box(Modifier.width(62.dp).height(2.dp).background(Color(0xFFE5A94D), RoundedCornerShape(2.dp)))
            Text(
                text = "by RAFAT AL ISLAM (RAKAN)",
                color = Color.White.copy(alpha = 0.88f),
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                fontFamily = FontFamily.SansSerif,
                letterSpacing = 1.1.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun AmarDokanApp(dao: StoreDao) {
    val scope = rememberCoroutineScope()
    val files by dao.files().collectAsStateWithLifecycle(emptyList())
    var activeId by remember { mutableStateOf<Long?>(null) }
    var code by remember { mutableStateOf("") }
    var decoded by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var showFileDialog by remember { mutableStateOf(false) }
    var newFileName by remember { mutableStateOf("") }
    var showProductDialog by remember { mutableStateOf(false) }
    var productName by remember { mutableStateOf("") }
    var productCode by remember { mutableStateOf("") }
    var buy by remember { mutableStateOf("") }
    var sell by remember { mutableStateOf("") }
    var stock by remember { mutableStateOf("1") }
    var transactionType by remember { mutableStateOf("SALE") }
    var showTransactionDialog by remember { mutableStateOf(false) }
    var selectedProductId by remember { mutableStateOf<Long?>(null) }
    var transactionQty by remember { mutableStateOf("1") }
    var transactionPrice by remember { mutableStateOf("") }
    var transactionAccount by remember { mutableStateOf("CASH") }
    var transactionNote by remember { mutableStateOf("") }
    var transactionError by remember { mutableStateOf<String?>(null) }
    var showLedgerDialog by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var ledgerType by remember { mutableStateOf("EXPENSE") }
    var ledgerAmount by remember { mutableStateOf("") }
    var ledgerAccount by remember { mutableStateOf("CASH") }
    var ledgerNote by remember { mutableStateOf("") }
    var ledgerError by remember { mutableStateOf<String?>(null) }
    val active = files.firstOrNull { it.id == activeId } ?: files.firstOrNull()
    LaunchedEffect(files) { if (activeId == null && files.isNotEmpty()) activeId = files.first().id }
    val products by if (active != null) dao.products(active.id).collectAsStateWithLifecycle(emptyList()) else remember { mutableStateOf(emptyList()) }
    val sales by if (active != null) dao.transactionSalesTotal(active.id).collectAsStateWithLifecycle(0.0) else remember { mutableStateOf(0.0) }
    val cashBalance by if (active != null) dao.accountBalance(active.id, "CASH").collectAsStateWithLifecycle(0.0) else remember { mutableStateOf(0.0) }
    val bkashBalance by if (active != null) dao.accountBalance(active.id, "BKASH").collectAsStateWithLifecycle(0.0) else remember { mutableStateOf(0.0) }
    val nagadBalance by if (active != null) dao.accountBalance(active.id, "NAGAD").collectAsStateWithLifecycle(0.0) else remember { mutableStateOf(0.0) }
    val bankBalance by if (active != null) dao.accountBalance(active.id, "BANK").collectAsStateWithLifecycle(0.0) else remember { mutableStateOf(0.0) }
    val ledger by if (active != null) dao.ledger(active.id).collectAsStateWithLifecycle(emptyList()) else remember { mutableStateOf(emptyList()) }

    Scaffold(containerColor = Color(0xFFF5F7F6), floatingActionButton = {
        if (active != null) FloatingActionButton(onClick = { showProductDialog = true }, containerColor = Green, contentColor = Color.White) { Icon(Icons.Default.Add, contentDescription = "পণ্য যোগ করুন") }
    }) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(top = 18.dp, bottom = 90.dp)) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Surface(shape = RoundedCornerShape(16.dp), color = Green, modifier = Modifier.size(52.dp)) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Store, null, tint = Color.White, modifier = Modifier.size(28.dp)) } }
                    Column(Modifier.weight(1f)) { Text("আমার দোকান", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink); Text("Amar Dokan · Rakan Edition", color = Color.Gray, fontSize = 12.sp) }
                    TextButton(onClick = { showFileDialog = true }) { Text("ফাইল +") }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Green), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("PRODUCT CODE SEARCH", color = Color.White.copy(alpha = .8f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("পণ্যের কোড থেকে ক্রয়মূল্য জানুন", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        OutlinedTextField(value = code, onValueChange = { code = it.uppercase(); decoded = null; error = null }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("যেমন: 10EA বা EFG") }, singleLine = true, colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Color.White, unfocusedBorderColor = Color.White.copy(alpha = .6f), focusedPlaceholderColor = Color.White.copy(alpha = .6f), unfocusedPlaceholderColor = Color.White.copy(alpha = .6f)))
                        Button(onClick = { val result = CodeDecoder.decode(code); decoded = result.getOrNull()?.let { "৳ ${it}" }; error = result.exceptionOrNull()?.message }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Green)) { Text("মূল্য বের করুন") }
                        decoded?.let { Text("ক্রয়মূল্য: $it", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold) }
                        error?.let { Text(it, color = Color(0xFFFFD6D6), fontSize = 13.sp) }
                    }
                }
            }
            item {
                Text("বর্তমান ব্যবসার ফাইল", fontWeight = FontWeight.Bold, color = Ink)
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(active?.name ?: "কোনো ফাইল নেই", fontWeight = FontWeight.SemiBold); Text("এই ফাইলের ডেটা আলাদাভাবে সংরক্ষিত", color = Color.Gray, fontSize = 12.sp) }
                        if (files.isNotEmpty()) { var expanded by remember { mutableStateOf(false) }; Box { TextButton(onClick = { expanded = true }) { Text("পরিবর্তন") }; DropdownMenu(expanded, { expanded = false }) { files.forEach { f -> DropdownMenuItem(text = { Text(f.name) }, onClick = { activeId = f.id; expanded = false; code = ""; decoded = null }) } } } }
                    }
                }
            }
            item { Text("ব্যবসার সারসংক্ষেপ", fontWeight = FontWeight.Bold, color = Ink) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricCard("মোট বিক্রি", "৳ ${"%.0f".format(sales)}", Modifier.weight(1f))
                    MetricCard("পণ্যের সংখ্যা", "${products.size}", Modifier.weight(1f))
                }
            }
            item {
                Text("লেনদেন ব্যবস্থাপনা", fontWeight = FontWeight.Bold, color = Ink)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { transactionType = "SALE"; selectedProductId = products.firstOrNull()?.id; transactionPrice = products.firstOrNull()?.sellingPrice?.toString() ?: ""; transactionError = null; showTransactionDialog = true }, modifier = Modifier.weight(1f), enabled = products.isNotEmpty()) { Icon(Icons.Default.PointOfSale, null); Spacer(Modifier.width(6.dp)); Text("বিক্রি") }
                    OutlinedButton(onClick = { transactionType = "PURCHASE"; selectedProductId = products.firstOrNull()?.id; transactionPrice = products.firstOrNull()?.purchasePrice?.toString() ?: ""; transactionError = null; showTransactionDialog = true }, modifier = Modifier.weight(1f), enabled = products.isNotEmpty()) { Icon(Icons.Default.ShoppingCart, null); Spacer(Modifier.width(6.dp)); Text("ক্রয়") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { ledgerType = "INCOME"; ledgerError = null; showLedgerDialog = true }, modifier = Modifier.weight(1f)) { Text("অন্যান্য আয় +") }
                    OutlinedButton(onClick = { ledgerType = "EXPENSE"; ledgerError = null; showLedgerDialog = true }, modifier = Modifier.weight(1f)) { Text("খরচ −") }
                }
            }
            item {
                Text("হিসাবের ব্যালেন্স", fontWeight = FontWeight.Bold, color = Ink)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetricCard("নগদ", "৳ ${"%.0f".format(cashBalance)}", Modifier.weight(1f))
                    MetricCard("বিকাশ", "৳ ${"%.0f".format(bkashBalance)}", Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetricCard("নগদ (Nagad)", "৳ ${"%.0f".format(nagadBalance)}", Modifier.weight(1f))
                    MetricCard("ব্যাংক", "৳ ${"%.0f".format(bankBalance)}", Modifier.weight(1f))
                }
                TextButton(onClick = { showHistory = !showHistory }) { Icon(Icons.Default.AccountBalanceWallet, null); Text(if (showHistory) "ইতিহাস লুকান" else "লেনদেনের ইতিহাস দেখুন (${ledger.size})") }
            }
            if (showHistory) {
                item { Text("সাম্প্রতিক লেনদেন", fontWeight = FontWeight.Bold, color = Ink) }
                if (ledger.isEmpty()) item { Text("এখনো কোনো লেনদেন নেই", color = Color.Gray) }
                items(ledger.take(30), key = { "ledger-${it.id}" }) { entry ->
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(12.dp)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text("${ledgerTypeLabel(entry.type)} · ${accountLabel(entry.account)}", fontWeight = FontWeight.SemiBold); Text(entry.note, color = Color.Gray, fontSize = 12.sp) }
                            Text("${if (entry.type == "SALE" || entry.type == "INCOME") "+" else "−"}৳ ${"%.2f".format(entry.amount)}", color = if (entry.type == "SALE" || entry.type == "INCOME") Green else Color(0xFFB34B4B), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            item { Text("পণ্যের তালিকা", fontWeight = FontWeight.Bold, color = Ink) }
            if (products.isEmpty()) item { Text("এখনো কোনো পণ্য যোগ করা হয়নি। নিচের + বাটনে চাপ দিয়ে পণ্য যোগ করুন।", color = Color.Gray, fontSize = 13.sp) }
            items(products, key = { it.id }) { p ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(15.dp)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(p.name, fontWeight = FontWeight.SemiBold, color = Ink); Text("কোড: ${p.code} · স্টক: ${p.stock}", color = Color.Gray, fontSize = 12.sp) }
                        Column(horizontalAlignment = Alignment.End) { Text("৳ ${p.sellingPrice}", color = Green, fontWeight = FontWeight.Bold); Text("ক্রয় ৳ ${p.purchasePrice}", color = Color.Gray, fontSize = 11.sp) }
                    }
                }
            }
        }
    }
    if (showFileDialog) AlertDialog(onDismissRequest = { showFileDialog = false }, title = { Text("নতুন ব্যবসার ফাইল") }, text = { OutlinedTextField(newFileName, { newFileName = it }, label = { Text("ফাইলের নাম") }, singleLine = true) }, confirmButton = { TextButton(onClick = { if (newFileName.isNotBlank()) scope.launch { activeId = dao.addFile(BusinessFile(name = newFileName.trim())); newFileName = ""; showFileDialog = false } }) { Text("তৈরি করুন") } }, dismissButton = { TextButton(onClick = { showFileDialog = false }) { Text("বাতিল") } })
    if (showProductDialog && active != null) AlertDialog(onDismissRequest = { showProductDialog = false }, title = { Text("নতুন পণ্য যোগ করুন") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(productName, { productName = it }, label = { Text("পণ্যের নাম") }, singleLine = true)
            OutlinedTextField(productCode, { productCode = it.uppercase() }, label = { Text("পণ্যের কোড") }, singleLine = true)
            OutlinedTextField(buy, { buy = it }, label = { Text("ক্রয়মূল্য (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            OutlinedTextField(sell, { sell = it }, label = { Text("বিক্রয়মূল্য (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            OutlinedTextField(stock, { stock = it }, label = { Text("স্টক") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
        }
    }, confirmButton = { TextButton(onClick = { val b = buy.toDoubleOrNull(); val s = sell.toDoubleOrNull(); val q = stock.toIntOrNull(); if (productName.isNotBlank() && productCode.isNotBlank() && b != null && s != null && q != null && q >= 0) scope.launch { dao.addProduct(Product(businessId = active.id, name = productName.trim(), code = productCode.trim(), purchasePrice = b, sellingPrice = s, stock = q)); productName = ""; productCode = ""; buy = ""; sell = ""; stock = "1"; showProductDialog = false } }) { Text("সংরক্ষণ") } }, dismissButton = { TextButton(onClick = { showProductDialog = false }) { Text("বাতিল") } })

    if (showTransactionDialog && active != null) {
        AlertDialog(onDismissRequest = { showTransactionDialog = false }, title = { Text(if (transactionType == "SALE") "পণ্য বিক্রি" else "পণ্য ক্রয়") }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                var productMenu by remember { mutableStateOf(false) }
                Box {
                    OutlinedButton(onClick = { productMenu = true }, modifier = Modifier.fillMaxWidth()) { Text(products.firstOrNull { it.id == selectedProductId }?.name ?: "পণ্য নির্বাচন করুন") }
                    DropdownMenu(expanded = productMenu, onDismissRequest = { productMenu = false }) { products.forEach { p -> DropdownMenuItem(text = { Text("${p.name} · স্টক ${p.stock}") }, onClick = { selectedProductId = p.id; transactionPrice = (if (transactionType == "SALE") p.sellingPrice else p.purchasePrice).toString(); productMenu = false }) } }
                }
                OutlinedTextField(transactionQty, { transactionQty = it }, label = { Text("পরিমাণ") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(transactionPrice, { transactionPrice = it }, label = { Text("প্রতি পণ্যের মূল্য (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                var accountMenu by remember { mutableStateOf(false) }
                Box { OutlinedButton(onClick = { accountMenu = true }, modifier = Modifier.fillMaxWidth()) { Text("হিসাব: ${accountLabel(transactionAccount)}") }; DropdownMenu(accountMenu, { accountMenu = false }) { listOf("CASH", "BKASH", "NAGAD", "BANK").forEach { a -> DropdownMenuItem(text = { Text(accountLabel(a)) }, onClick = { transactionAccount = a; accountMenu = false }) } } }
                OutlinedTextField(transactionNote, { transactionNote = it }, label = { Text("নোট (ঐচ্ছিক)") }, singleLine = true)
                transactionError?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
            }
        }, confirmButton = { TextButton(onClick = {
            val q = transactionQty.toIntOrNull(); val price = transactionPrice.toDoubleOrNull(); val pid = selectedProductId
            if (q == null || q <= 0 || price == null || price < 0 || pid == null) transactionError = "পণ্যের পরিমাণ ও মূল্য সঠিকভাবে দিন"
            else scope.launch { try { if (transactionType == "SALE") dao.recordSale(active.id, pid, q, price, transactionAccount, transactionNote) else dao.recordPurchase(active.id, pid, q, price, transactionAccount, transactionNote); showTransactionDialog = false; transactionQty = "1"; transactionNote = "" } catch (e: Exception) { transactionError = e.message ?: "লেনদেন সংরক্ষণ করা যায়নি" } }
        }) { Text("সংরক্ষণ") } }, dismissButton = { TextButton(onClick = { showTransactionDialog = false }) { Text("বাতিল") } })
    }
    if (showLedgerDialog && active != null) {
        AlertDialog(onDismissRequest = { showLedgerDialog = false }, title = { Text(if (ledgerType == "INCOME") "অন্যান্য আয় যোগ করুন" else "খরচ যোগ করুন") }, text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(ledgerAmount, { ledgerAmount = it }, label = { Text("পরিমাণ (৳)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                var accountMenu by remember { mutableStateOf(false) }
                Box { OutlinedButton(onClick = { accountMenu = true }, modifier = Modifier.fillMaxWidth()) { Text("হিসাব: ${accountLabel(ledgerAccount)}") }; DropdownMenu(accountMenu, { accountMenu = false }) { listOf("CASH", "BKASH", "NAGAD", "BANK").forEach { a -> DropdownMenuItem(text = { Text(accountLabel(a)) }, onClick = { ledgerAccount = a; accountMenu = false }) } } }
                OutlinedTextField(ledgerNote, { ledgerNote = it }, label = { Text("বিবরণ") }, singleLine = true)
                ledgerError?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
            }
        }, confirmButton = { TextButton(onClick = { val amount = ledgerAmount.toDoubleOrNull(); if (amount == null || amount <= 0 || ledgerNote.isBlank()) ledgerError = "সঠিক পরিমাণ ও বিবরণ দিন" else scope.launch { try { if (ledgerType == "INCOME") dao.recordIncome(active.id, ledgerAccount, amount, ledgerNote) else dao.recordExpense(active.id, ledgerAccount, amount, ledgerNote); showLedgerDialog = false; ledgerAmount = ""; ledgerNote = "" } catch (e: Exception) { ledgerError = e.message } } }) { Text("সংরক্ষণ") } }, dismissButton = { TextButton(onClick = { showLedgerDialog = false }) { Text("বাতিল") } })
    }
}

@Composable private fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) { Text(title, color = Color.Gray, fontSize = 12.sp); Text(value, color = Ink, fontSize = 21.sp, fontWeight = FontWeight.Bold) } }
}

private fun accountLabel(account: String): String = when (account) { "CASH" -> "নগদ"; "BKASH" -> "বিকাশ"; "NAGAD" -> "নগদ (Nagad)"; "BANK" -> "ব্যাংক"; else -> account }
private fun ledgerTypeLabel(type: String): String = when (type) { "SALE" -> "বিক্রি"; "PURCHASE" -> "ক্রয়"; "INCOME" -> "আয়"; "EXPENSE" -> "খরচ"; else -> type }
