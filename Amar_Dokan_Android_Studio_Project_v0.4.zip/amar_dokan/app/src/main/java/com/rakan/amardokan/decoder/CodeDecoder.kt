package com.rakan.amardokan.decoder

/** Implements the two code systems described in the Amar Dokan specification. */
object CodeDecoder {
    private val first = mapOf('E' to 1, 'F' to 2, 'G' to 3, 'H' to 4, 'I' to 5, 'J' to 6, 'K' to 7, 'L' to 8, 'M' to 9, 'N' to 0)
    private val second = mapOf('A' to 25, 'B' to 50, 'C' to 75, 'D' to 100, 'E' to 200)

    fun decode(raw: String): Result<Int> = runCatching {
        val code = raw.trim().uppercase()
        require(code.isNotEmpty()) { "কোড লিখুন" }
        require(code.all { it.isLetterOrDigit() }) { "কোডে শুধু ইংরেজি অক্ষর ও সংখ্যা ব্যবহার করুন" }
        val useSecond = code.first().isDigit() || code.last().isDigit()
        if (!useSecond) {
            require(code.all { it in first }) { "প্রথম কোড সিস্টেমে E–N অক্ষর ব্যবহার করুন" }
            return@runCatching code.sumOf { first.getValue(it) }
        }
        require(code.any { it.isLetter() }) { "কোডে অন্তত একটি অক্ষর থাকতে হবে" }
        require(code.all { it.isDigit() || it in second }) { "দ্বিতীয় কোড সিস্টেমে শুধু A–E ও সংখ্যা ব্যবহার করুন" }

        // Parse letter-led groups. A number immediately before a letter is subtracted;
        // a number immediately after a letter is added. Each letter group is independent.
        var total = 0
        var i = 0
        while (i < code.length) {
            if (code[i].isDigit()) {
                val start = i
                while (i < code.length && code[i].isDigit()) i++
                val number = code.substring(start, i).toInt()
                require(i < code.length && code[i].isLetter()) { "সংখ্যার পরে একটি অক্ষর থাকতে হবে" }
                val letter = code[i++]
                var value = second.getValue(letter) - number
                if (i < code.length && code[i].isDigit()) {
                    val end = i
                    while (i < code.length && code[i].isDigit()) i++
                    value += code.substring(end, i).toInt()
                }
                total += value
            } else {
                val letter = code[i++]
                var value = second.getValue(letter)
                if (i < code.length && code[i].isDigit()) {
                    val start = i
                    while (i < code.length && code[i].isDigit()) i++
                    value += code.substring(start, i).toInt()
                }
                total += value
            }
        }
        total
    }
}
