# আমার দোকান (Amar Dokan) — Rakan Edition

Android Studio project using Kotlin, Jetpack Compose, Room and SQLite.

## Included in this project
- Bangla-first dashboard with a single prominent product-code search.
- Two-system custom product code decoder.
- Local Room database and business-file scoped data.
- Product creation and product listing.
- Purchase and sales forms in the dashboard, with product, quantity, unit price and payment account selection.
- Purchase/sale saves update stock and ledger atomically; sales are rejected when stock is insufficient.
- Other income and expense entry forms.
- Separate Cash, bKash, Nagad and Bank balances.
- Recent ledger history view (latest 30 entries).
- Per-business purchase/sales totals and per-account balance queries.

## Open the project
1. Extract this ZIP.
2. Open the `amar_dokan` folder in Android Studio.
3. Allow Gradle sync and install the Android SDK platform/build tools requested by Android Studio.
4. Run the `app` configuration on an emulator or Android device.

## Release limitations
- This is a source project archive, not a signed APK.
- The current database uses destructive fallback migration for this development build. Do not upgrade a production database with valuable data until proper Room migrations are added.
- PDF/Excel export, PIN lock, backup/restore, Firebase authentication/cloud sync, product edit/delete screens, full reports/profit calculation, and release signing remain to be completed.
- Firebase requires the owner's Firebase project and `google-services.json` configuration. A signed APK requires an app signing key.

See `DECODER_TESTS.md` for the requested decoder examples and test notes.
- A custom 2-second opening screen with a dark green gradient, store icon, serif-styled `Amar Dokan_ আমার দোকান` title, and `by RAFAT AL ISLAM (RAKAN)` credit.
