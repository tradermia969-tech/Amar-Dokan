# Decoder verification cases

| Code | Expected |
|---|---:|
| `10EA` | 215 |
| `3A` | 22 |
| `A3` | 28 |
| `10EEA5` | 420 |

The second code system is selected whenever the complete code starts or ends with a digit. A leading number is subtracted from the following letter value; a trailing number is added. Each letter group is evaluated independently and then summed.
